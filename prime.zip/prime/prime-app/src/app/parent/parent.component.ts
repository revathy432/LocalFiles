import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { HomeserviceService } from '../home/service/homeservice.service';
import { City } from '../home/model/home-interface';
import { query } from '@angular/animations';

@Component({
    selector: 'app-parent',
    templateUrl: './parent.component.html',
    styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {

    cities: City[];
    country: any;
    // @Output() country = new EventEmitter();
    selectedCity: any[];
    filteredBrands: any[];
    cityData: any[];
    output: string[];
    filteredCountriesSingle: any;


    // brands: string[] = ['Audi','BMW','Fiat','Ford','Honda','Jaguar','Mercedes','Renault','Volvo','VW'];
    // filteredBrands: any[];

    // brand: string;




    constructor(private service: HomeserviceService) { }

    ngOnInit() {
        this.service.getData()
            .subscribe((data: City[]) => {

                this.cities = data;
                console.log(data);
            });

    }
    filterCountrySingle(event) {
        let query = event.query;
        let cities = this.getResult();
        this.filteredCountriesSingle = this.filterCountry(query, cities);
    }
    filterCountry(query, cities: any[]) {

        let filtered: any[] = [];
        for (let i = 0; i < cities.length; i++) {
            let country = cities[i];
            if (country.name.toLowerCase().indexOf(query.toLowerCase()) == 0) {
                filtered.push(country);
            }
        }
        return filtered;
    }
    getResult() {
        return this.cities;
    }
    // search(event) {
    //     console.log('event', event);
    //     this.cityData = this.cities.filter(c => c.name.startsWith(this.country));
    //     // console.log(this.cities);
    //     // this.output = this.cityData.name;
    //     for (let t of this.cityData) {
    //         this.output = t.name
    //     }
    //     console.log(this.output);


    // }
    // getData() {
    //     return this.cityData.name;

    // }
}

    // onClick() {
    //     this.country.emit(this.selectedCity);
    //     console.log(this.selectedCity);
    // }

    // filterCountrySingle(event) {
    //     let query = event.query;

    //     this.service.getCountries().subscribe(cities => {
    //         this.filteredCountriesSingle = this.filterCountry(query, this.cities);
    //     });
    // }
    // filterCountry(query, cities) {
    //     console.log(this.cities.length);
    //     //in a real application, make a request to a remote url with the query and return filtered results, for demo we filter at client side
    //     this.filtered = [];
    //     for (let i = 0; i < cities.length; i++) {
    //         let City = cities[i];
    //         if (City.name.toLowerCase().indexOf(query.toLowerCase()) == 0) {
    //             this.filtered.push(City);
    //         }
    //     }
    //     return this.filtered;
    // }

// search(event) {
//   let query =event.query;
//   this.service.getData().subscribe(data => {
//       this.cities = data;
//   });
// }
//   
