import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { FormsModule } from '@angular/forms';
import { DropdownModule } from 'primeng/dropdown';
import { HttpClientModule } from '@angular/common/http';
import { ChildComponent } from './home/child/child.component';
import { ButtonModule } from 'primeng/button';

import { CanDeactivateGuard } from './can-deactivate.guard';
import { HttpModule } from '@angular/http';
import { TableModule } from 'primeng/table';
import { ParentComponent } from './parent/parent.component';
import { ListTodoComponent } from './list-todo/list-todo.component';
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ChildComponent,
    ParentComponent,
    ListTodoComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AutoCompleteModule,
    FormsModule,
    DropdownModule,
    BrowserAnimationsModule,
    HttpClientModule,
    ButtonModule,
    HttpModule,
    TableModule

  ],
  providers: [CanDeactivateGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
