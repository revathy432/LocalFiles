import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { City, User } from '../model/home-interface';
import { HomeserviceService } from '../service/homeservice.service';


@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
  // @Input() cities:City[];
  // @Output() country = new EventEmitter();
  selectedCity: any;
  citie: any[];
  userDetails: User[];
  cities: City[];
  frozenCols: any[];

  scrollableCols: any[];
  filterData: any[];
  cols: any;




  message: any[];

  constructor(private service: HomeserviceService) {

  }



  ngOnInit() {
    // this.filterData = this.service.getOption();
    // console.log(this.filterData.selectedCity);
    this.service.getMessage().subscribe(message => {
      // console.log('test', message);
      this.filterData = message;
    });
    // const test = this.service.getMessage();

    // console.log('this', this.filterData);
    this.cols = [
      { field: 'name', header: 'Name' },
      { field: 'age', header: 'Age' },
      { field: 'city', header: 'City' },
      { field: 'state', header: 'State' },
      { field: 'phone', header: 'Mobil Number' },
      { field: 'email', header: 'Email' }
    ];
    this.frozenCols = [
      { field: 'name', header: 'Name' },
    ];
  }
}


  //   onClick(){
  // this.country.emit(this.selectedCity);
  // console.log(this.selectedCity);
  //   }

