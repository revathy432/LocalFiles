import { Component, OnInit } from '@angular/core';
import { HomeModel } from './model/home-model'
import { Router, ActivatedRoute } from '@angular/router';
import { HomeserviceService } from './service/homeservice.service';
import { City, User } from './model/home-interface';
import { HttpClient } from '@angular/common/http';


import { Observable } from 'rxjs';
import { CanComponentDeactivate } from '../can-deactivate.guard';
import { query } from '@angular/animations';
import { Http } from '@angular/http';
import { SelectItem } from 'primeng/api/selectitem';
// interface City {
//   name: string,
//   code: string
// }
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})



export class HomeComponent implements OnInit {
  homeModel: HomeModel;
  citie: string[];
  // cities: { name: string; id: string; city:string }[];
  cities: City[];

  // userDetails: UserDetails[];
  city: string[];

  name: string;
  selectedCity: any;
  userDetails: User[];

  filterData: any[];
  constructor(private router: Router, private service: HomeserviceService, private http: HttpClient) {


  }

  ngOnInit() {
    this.service.getData()
      .subscribe((data: City[]) => {
        console.log(data);
        this.cities = data;
      });
    this.service.getUserDetails()
      .subscribe((data: User[]) => {

        this.userDetails = data;
        console.log(data);
      });
  }

  getAllUserDetails() {

  }
  // display(){
  //   this.selectedCity=true;
  //    this.service.getData(this.name)
  //    .subscribe(value =>this.cities=value as string[]);
  //  }

  // this.name=this.router.snapshot.paramMap.get('name');
  // getValue() {

  //   this.citie = [];

  //   this.userDetails.forEach(element => {
  //     if (element.name == this.selectedCity.name) {
  //       this.citie.push(element);
  //     }
  //     console.log(this.citie);
  //     return this.citie;
  //   });
  getValue() {
    // this.service.setOption('selectedCity', this.selectedCity);

    this.filterData = this.userDetails.filter(x => x.name === this.selectedCity.name);
    // this.userDetails.push(this.selectedCity);
    // console.log(this.filterData);
    // debugger;
    this.service.sendMessage(this.filterData);
    this.router.navigate(['/child']);
    console.log(this.selectedCity);
    console.log(this.filterData);
    return this.filterData;
  }

}



// getCity($event){
//  this.selectedCity=$event;
//  console.log(this.selectedCity);
// this.saved=true;

// }
// onSubmit(){

//   console.log(this.selectedCity);
// }
// canDeactivate(): Observable<boolean> | boolean {
//   if (this.selectedCity==null && !this.saved) {
//     return confirm('Your changes are unsaved!! Do you like to exit');
//   }
//   return true;
// }
// canExit():boolean{
//   if (confirm("Do you wish to Please confirm")) {
//     return true
//   } else {
//     return false
//   }
// }

