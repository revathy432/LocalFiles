import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject, Subject } from 'rxjs';
import { Http } from '@angular/http';
import { City, User } from '../model/home-interface';


@Injectable({
  providedIn: 'root'
})
export class HomeserviceService {
  baseUrl: string = "http://localhost:3000";

  getCountry: any;
  cities: City[];
  selectedCity: any;
  userDetails: User[];

  // message: any[];

  // private subject = new Subject<any>();
  private messagecity: BehaviorSubject<any>;
  // public messagecity = this.subject.asObservable();
  constructor(private https: Http, private http: HttpClient) {
    this.messagecity = new BehaviorSubject('ui');
  }
  getData() {
    return this.http.get(`http://localhost:3000/cities`);
  }
  getUserDetails() {
    return this.http.get(`http://localhost:3000/userDetails`);
  }
  getCountries() {
    return this.https.get(`${this.baseUrl}/cities`);
  }

  sendMessage(message) {
    this.messagecity.next(message);

  }

  // clearMessage() {
  //   this.subject.next();
  // }

  getMessage() {
    return this.messagecity.asObservable();
  }
  // messageCity = this.subject.asObservable();
  // sendMessage(message: any[]) {
  //   this.subject.next(message);
  // }
}