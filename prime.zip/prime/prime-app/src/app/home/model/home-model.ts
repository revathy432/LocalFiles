import { City } from "./home-interface";

export class HomeModel {
    cities: City[];

    selectedCity: City;
    constructor() {

    }

}