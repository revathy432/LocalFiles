export interface City {
  // toLowerCase();



  name: string,
  id: string,
  town: string
}
export interface User {
  name: string;
  age: string;
  phone: number;
  email: string;

  city: string;
  state: string;

}