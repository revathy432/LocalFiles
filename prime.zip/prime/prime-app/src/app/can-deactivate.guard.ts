import { CanDeactivate } from '@angular/router';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { HomeComponent } from './home/home.component';


export interface CanComponentDeactivate {
    canExit: () => Observable<boolean> | Promise<boolean> | boolean;
}


@Injectable({
    providedIn: 'root',
})

export class CanDeactivateGuard implements 
    CanDeactivate<CanComponentDeactivate> {

    canDeactivate(component: CanComponentDeactivate) {

        return component.canExit ? component.canExit():true;
    }
}