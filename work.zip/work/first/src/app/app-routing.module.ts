import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';

import { WelcomeComponent } from './welcome/welcome.component';
import { ErrorComponent } from './error/error.component';
import { MenubarComponent } from './menubar/menubar.component';
import { ListTodoComponent } from './list-todo/list-todo.component';
import { LogoutComponent } from './logout/logout.component';


const routes: Routes = [{ path: 'home', component: HomeComponent }, { path: 'welcome/:name', component: WelcomeComponent }, { path: 'todos', component: ListTodoComponent }, { path: 'logout', component: LogoutComponent }, { path: '**', component: ErrorComponent }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
