import { Component, OnInit } from '@angular/core';
import {MenuItem} from 'primeng/api';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
 
    private items: MenuItem[];
    title: string;
   
    ngOnInit() {
   
      this.title = "This is my first example with PrimeNG and Angular !"; 
      this.items = [
            {label:'Games'},
            {label:'Strategy'},
            {label:'Heroes III', }
        ];
    }
  }