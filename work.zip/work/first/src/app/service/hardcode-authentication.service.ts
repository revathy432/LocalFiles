import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HardcodeAuthenticationService {
  userName: boolean = false;
  public isUserLoggedIn = new Subject();
  constructor() { }
  authenticate(username: string, password: string): Observable<boolean> | boolean {
    // console.log('before' + this.isUserLoggedIn());
    if (username === "revathy" && password === 'rev') {
      sessionStorage.setItem('authenticaterUser', username);
      this.userName = true;
      this.isUserLoggedIn.next(true);
      // console.log('after' + this.isUserLoggedIn());
      return this.userName;
    }
    else {

      this.isUserLoggedIn.next(false);
      return this.userName;
    }
  }
  logout() {
    this.userName = false;
    this.isUserLoggedIn.next(false);
    sessionStorage.removeItem('authenticaterUser');
  }
  // isUserLoggedIn() {
  //   let user = sessionStorage.getItem('authenticaterUser');
  //   return !(user === null);
  // }
}
