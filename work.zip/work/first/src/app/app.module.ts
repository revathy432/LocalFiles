import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { BreadcrumbModule } from 'primeng/breadcrumb';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { WelcomeComponent } from './welcome/welcome.component';
import { ErrorComponent } from './error/error.component';
import { MenubarModule } from 'primeng/menubar';
import { MenuItem } from 'primeng/api';
import { MenubarComponent } from './menubar/menubar.component';
import { ButtonModule } from 'primeng/button';
import { ListTodoComponent } from './list-todo/list-todo.component';
import { TableModule } from 'primeng/table';
import { LogoutComponent } from './logout/logout.component';
import { ConfirmDialogModule } from 'primeng/confirmdialog';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MessagesModule } from 'primeng/messages';
import { MessageModule } from 'primeng/message';



@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    WelcomeComponent,
    ErrorComponent,
    MenubarComponent,
    ListTodoComponent,
    LogoutComponent
  ],
  imports: [
    BrowserModule, BreadcrumbModule, AutoCompleteModule, FormsModule, ReactiveFormsModule,
    AppRoutingModule,
    MenubarModule,
    ButtonModule,
    TableModule,
    ConfirmDialogModule,
    BrowserAnimationsModule,
    MessagesModule,
    MessageModule


  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
