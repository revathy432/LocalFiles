import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-todo',
  templateUrl: './list-todo.component.html',
  styleUrls: ['./list-todo.component.css']
})
export class ListTodoComponent implements OnInit {
  cols: any;
  todos: any[];
  constructor() { }

  ngOnInit() {
    this.cols = [
      { field: 'name', header: 'Name' },
      { field: 'age', header: 'Age' }
      // { field: 'state', header: 'State' },
      // { field: 'city', header: 'City' }
    ];
    this.todos = [
      { name: 'revathy', age: '22 years' },
      { name: 'geetha', age: '23 years' },
      { name: 'savitha', age: '23 years' },
    ]
  }

}
