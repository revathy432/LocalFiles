export class menu {
    label: string;
    icon: string;
    items: [];

}