import { MenuItem } from 'primeng/api';
import { HardcodeAuthenticationService } from 'src/app/service/hardcode-authentication.service';
export class MenuModel {


    // service: HardcodeAuthenticationService;
    // isUserLoggedIn: boolean = this.service.isUserLoggedIn();
    constructor() {

    }
}