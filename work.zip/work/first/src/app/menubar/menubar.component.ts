import { Component, OnInit } from '@angular/core';
import { MenuModel } from './model/menu-model';
import { HardcodeAuthenticationService } from '../service/hardcode-authentication.service';
import { MenuItem } from 'primeng/api/menuitem';

@Component({
  selector: 'app-menubar',
  templateUrl: './menubar.component.html',
  styleUrls: ['./menubar.component.css']
})
export class MenubarComponent implements OnInit {
  menuModel: MenuModel
  isUserLoggedIn = false;
  // userName: string;
  items: MenuItem[];
  userName: any = false;
  constructor(private service: HardcodeAuthenticationService) {
    this.menuModel = new MenuModel;
  }

  ngOnInit() {
    // this.service.isUserLoggedIn.subscribe(name => this.userName = name);
    // this.items = [
    //   {
    //     label: 'HOME',
    //     routerLink: ['/home']


    //   },
    //   {
    //     label: 'TODOS',
    //     routerLink: ['/todos']


    //   }
    // ];
    this.service.isUserLoggedIn
      .subscribe(Response => {
        this.userName = Response
        this.items = [
          {
            label: 'HOME',
            routerLink: ['/home']


          },
          {
            label: 'TODOS',
            routerLink: ['/todos'],
            visible: this.userName

          }
        ];
      })
    console.log(this.userName);

  }
  save() {
    this.service.logout();

  }
}
