import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HardcodeAuthenticationService } from '../service/hardcode-authentication.service';
import { ConfirmationService } from 'primeng/api';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers: [
    ConfirmationService,
  ]
})
export class HomeComponent implements OnInit {
  username = ''
  password = ''
  errorMessage = 'invalid'
  invalidLogin = false;
  msgs: any[];

  constructor(private router: Router, private service: HardcodeAuthenticationService, private confirmation: ConfirmationService) { }

  ngOnInit() {
  }
  handleLogin() {

    if (this.service.authenticate(this.username, this.password)) {
      this.router.navigate(['welcome', this.username]);
      this.invalidLogin = false;
    }
    else {
      this.invalidLogin = true;

    }
    this.msgs = [];
    this.msgs.push({ severity: 'error', summary: 'Error Message', detail: 'Validation failed' });
    // this.confirmation.confirm({
    //   key: 'confirm-drop-database',
    //   message: 'Are you sure to remove all data?',
    //   accept: () => { this.invalidLogin = true; },
    // });
  }
}

